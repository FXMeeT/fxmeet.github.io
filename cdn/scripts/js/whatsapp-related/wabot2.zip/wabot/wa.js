const WebSocket = require("ws");

const WS_PORT = 4567;
const OLLAMA_URL = "http://localhost:11434/api/generate";

const wss = new WebSocket.Server({ port: WS_PORT });

console.log(`[WS] Server running on ws://localhost:${WS_PORT}`);

function callOllama(prompt) {
    return new Promise(async (resolve, reject) => {
        const controller = new AbortController();

        const timeout = setTimeout(() => {
            controller.abort();
            reject("OLLAMA_TIMEOUT");
        }, 60000);

        try {
            const res = await fetch(OLLAMA_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    model: "llama3.2:3b",   // IMPORTANT: must exist in `ollama list`
                    prompt: prompt,
                    stream: false
                }),
                signal: controller.signal
            });

            clearTimeout(timeout);

            if (!res.ok) {
                const text = await res.text();
                return reject(`OLLAMA_HTTP_ERROR: ${res.status} ${text}`);
            }

            const data = await res.json();

            if (!data?.response) {
                return reject("EMPTY_OLLAMA_RESPONSE");
            }

            resolve(data.response);

        } catch (err) {
            clearTimeout(timeout);
            reject(err.message || err);
        }
    });
}

wss.on("connection", (ws) => {
    console.log("[WS] Client connected");

    ws.on("message", async (msg) => {
        let input;

        try {
            input = JSON.parse(msg.toString());
        } catch {
            return ws.send(JSON.stringify({
                type: "response",
                text: "Invalid request format"
            }));
        }

        if (!input.text) {
            return ws.send(JSON.stringify({
                type: "response",
                text: "Empty prompt"
            }));
        }

        try {
            const result = await callOllama(input.text);

            ws.send(JSON.stringify({
                type: "response",
                text: result
            }));

        } catch (err) {
            console.error("[OLLAMA ERROR]", err);

            ws.send(JSON.stringify({
                type: "response",
                text: "Model error or timeout. Try again."
            }));
        }
    });

    ws.on("close", () => {
        console.log("[WS] Client disconnected");
    });
});
