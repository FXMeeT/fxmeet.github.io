const WebSocket = require("ws");

const WS_PORT = 4567;
const OLLAMA_URL = "http://localhost:11434/api/generate";

/*
========================
CONFIG (edit everything here)
========================
*/
const CONFIG = {
    model: "llama3.2:3b",

    // generation control (tokens, not words)
    maxTokens: 50,

    // output control (words, UI safety)
    maxWords: 60,
    truncationMessage: "(message truncated to 60 words)",

    // prompt behavior
    wordInstruction: true,
    wordInstructionLimit: 60,

    // runtime safety
    timeoutMs: 60000,

    // model randomness
    temperature: 0.7,

    // auto continue if cut mid-sentence
    autoContinue: false,
    maxContinueRounds: 2
};

const wss = new WebSocket.Server({ port: WS_PORT });

console.log(`[WS] Server running on ws://localhost:${WS_PORT}`);

function trimToWords(text, maxWords, truncMsg) {
    if (!text) return "";

    const words = text.trim().split(/\s+/);

    if (words.length <= maxWords) return text;

    return (
        words.slice(0, maxWords).join(" ") + " " + truncMsg
    );
}

function looksTruncated(text) {
    if (!text) return false;
    const t = text.trim();
    return !/[.!?]$/.test(t);
}

function callOllama(prompt) {
    return new Promise(async (resolve, reject) => {
        const controller = new AbortController();

        const timeout = setTimeout(() => {
            controller.abort();
            reject("OLLAMA_TIMEOUT");
        }, CONFIG.timeoutMs);

        try {
            const finalPrompt = CONFIG.wordInstruction
                ? `Answer in maximum ${CONFIG.wordInstructionLimit} words only: ${prompt}`
                : prompt;

            const res = await fetch(OLLAMA_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    model: CONFIG.model,
                    prompt: finalPrompt,
                    stream: false,
                    options: {
                        num_predict: CONFIG.maxTokens,
                        temperature: CONFIG.temperature
                    }
                }),
                signal: controller.signal
            });

            clearTimeout(timeout);

            if (!res.ok) {
                const text = await res.text();
                return reject(`OLLAMA_HTTP_ERROR: ${res.status} ${text}`);
            }

            const data = await res.json();

            if (!data?.response) {
                return reject("EMPTY_OLLAMA_RESPONSE");
            }

            resolve(data.response);

        } catch (err) {
            clearTimeout(timeout);
            reject(err.message || err);
        }
    });
}

wss.on("connection", (ws) => {
    console.log("[WS] Client connected");

    ws.on("message", async (msg) => {
        let input;

        try {
            input = JSON.parse(msg.toString());
        } catch {
            return ws.send(JSON.stringify({
                type: "response",
                text: "Invalid request format"
            }));
        }

        if (!input.text) {
            return ws.send(JSON.stringify({
                type: "response",
                text: "Empty prompt"
            }));
        }

        try {
            let result = await callOllama(input.text);

            // optional auto-continue
            if (CONFIG.autoContinue) {
                let rounds = 0;

                while (looksTruncated(result) && rounds < CONFIG.maxContinueRounds) {
                    rounds++;

                    const next = await callOllama(
                        `Continue exactly where you left off. Do not repeat:\n\n${result}`
                    );

                    result += " " + next;
                }
            }

            // final safety trim (always applied)
            result = trimToWords(result, CONFIG.maxWords, CONFIG.truncationMessage);

            ws.send(JSON.stringify({
                type: "response",
                text: result
            }));

        } catch (err) {
            console.error("[OLLAMA ERROR]", err);

            ws.send(JSON.stringify({
                type: "response",
                text: "Model error or timeout. Try again."
            }));
        }
    });

    ws.on("close", () => {
        console.log("[WS] Client disconnected");
    });
});
