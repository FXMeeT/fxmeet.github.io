const ws = new WebSocket("ws://localhost:4567");

// track valid WhatsApp tabs
const readyTabs = new Set();

// ---- REGISTER CONTENT SCRIPT ----
chrome.runtime.onMessage.addListener((msg, sender) => {

    if (msg.type === "CONTENT_READY") {
        if (sender.tab?.id != null) {
            readyTabs.add(sender.tab.id);
        }
    }

    if (msg.type === "BOT_REQUEST") {
        ws.send(JSON.stringify({ text: msg.text }));
    }
});

// ---- CLEAN DEAD TABS ----
function safeSend(tabId, message) {
    chrome.tabs.sendMessage(tabId, message, () => {
        if (chrome.runtime.lastError) {
            readyTabs.delete(tabId);
        }
    });
}

// ---- RECEIVE GEMINI RESPONSE ----
ws.onmessage = (event) => {
    const response = event.data;

    for (const tabId of readyTabs) {
        safeSend(tabId, {
            type: "BOT_RESPONSE",
            text: response
        });
    }
};
