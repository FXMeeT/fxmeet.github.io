import time
import math
import pyautogui

# --- SETTINGS ---
AMPLITUDE = 5          # ±5px = 10px peak-to-peak
FREQUENCY = 0.5        # sine cycles per second
SCROLL_SPEED = 25      # pixels per second (down)
INTERVAL = 0.01        # update rate

print("Running stable sine motion + scroll... Ctrl+C to stop.")

# FIXED CENTER (prevents drift)
center_x, center_y = pyautogui.position()

start_time = time.time()
last_time = start_time

try:
    while True:
        now = time.time()
        t = now - start_time

        # --- sine wave offset (no drift) ---
        x_offset = math.sin(2 * math.pi * FREQUENCY * t) * AMPLITUDE

        pyautogui.moveTo(center_x + x_offset, center_y)

        # --- time-based scrolling (25 px/sec) ---
        dt = now - last_time
        if dt > 0:
            pyautogui.scroll(int(-SCROLL_SPEED * dt))
            last_time = now

        time.sleep(INTERVAL)

except KeyboardInterrupt:
    print("Stopped.")
