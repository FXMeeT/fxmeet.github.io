let lastMessage = null;
let processing = false;
let ws = null;

// ===============================
// CONFIG
// ===============================
const targetHandle = "@vazebusiness";

// persistent storage (NEVER reset unless new message arrives)
let lastUserMentioned = null;

// ===============================
// INPUT BOX
// ===============================
function getInputBox() {
    return document.querySelector('[data-testid="conversation-compose-box-input"]');
}

// ===============================
// TEXT HELPERS
// ===============================
function setText(el, text) {
    if (!el) return;

    el.focus();
    el.innerHTML = "";
    document.execCommand("insertText", false, text);
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
}

function insertText(el, text) {
    if (!el) return;

    el.focus();
    document.execCommand("insertText", false, text);
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
}

function pressEnter(el) {
    el?.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        bubbles: true
    }));
}

function pressShiftEnter(el) {
    el?.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        shiftKey: true,
        bubbles: true
    }));
}

// ===============================
// MESSAGE PARSER
// ===============================
function getText(msg) {
    const el = msg.querySelector('[data-testid="selectable-text"] span');
    return el ? el.innerText.trim() : "";
}

// 🔥 IMPORTANT: EXACT AUTHOR EXTRACTION (YOUR IDEA IMPLEMENTED)
function getAuthor(msg) {
    const el = msg.querySelector('[data-testid="author"]');
    if (!el) return null;

    const name = el.innerText.trim();
    return name || null;
}

// ===============================
// FIND LATEST MENTION
// ===============================
function findLatestMention() {
    const messages = [...document.querySelectorAll('div[data-testid^="conv-msg-"]')];

    const matched = messages
        .map(msg => {
            const text = getText(msg);
            const author = getAuthor(msg);

            return {
                msg,
                text,
                author,
                hasMention: text.includes(targetHandle)
            };
        })
        .filter(m => m.hasMention);

    return matched.length ? matched[matched.length - 1] : null;
}

// ===============================
// WS
// ===============================
function connectWS() {
    ws = new WebSocket("ws://localhost:4567");

    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);

        if (data.type === "response") {
            handleResponse(data.text);
        }

        processing = false;
    };

    ws.onclose = () => setTimeout(connectWS, 2000);
}

connectWS();

// ===============================
// RESPONSE FLOW (STRICT ORDER YOU WANTED)
// ===============================
async function handleResponse(text) {
    const el = getInputBox();
    if (!el) return;

    const username = lastUserMentioned;

    if (!username) return;

    // STEP 1: type @username EXACTLY
    setText(el, `@${username}`);

    await new Promise(r => setTimeout(r, 200));

    // STEP 2: press enter
    pressEnter(el);

    await new Promise(r => setTimeout(r, 200));

    // STEP 3: shift+enter
    pressShiftEnter(el);

    await new Promise(r => setTimeout(r, 200));

    // STEP 4: paste ollama response
    insertText(el, text);

    await new Promise(r => setTimeout(r, 200));

    // STEP 5: send
    pressEnter(el);
}

// ===============================
// MAIN LOOP
// ===============================
setInterval(() => {
    if (processing) return;

    const latest = findLatestMention();
    if (!latest) return;

    const text = latest.text;

    if (text === lastMessage) return;

    lastMessage = text;

    if (!text.includes(targetHandle)) return;

    const cleaned = text.replace(new RegExp(targetHandle, "g"), "").trim();
    if (!cleaned) return;

    // 🔥 STORE EXACT AUTHOR (NO FALLBACKS)
    if (latest.author) {
        lastUserMentioned = latest.author;
    } else {
        // if no author exists, IGNORE message entirely
        return;
    }

    latest.msg.style.border = "2px solid red";
    latest.msg.scrollIntoView({ behavior: "smooth", block: "center" });

    processing = true;

    ws?.send(JSON.stringify({
        type: "request",
        text: cleaned,
        username: lastUserMentioned
    }));

}, 50);
