let lastMessage = null;
let processing = false;
let ws = null;

// ===============================
// CONFIG
// ===============================
const targetHandle = "@vazebusiness";
let lastUserMentioned = null;

// ===============================
// INPUT BOX
// ===============================
function getInputBox() {
    return document.querySelector('[data-testid="conversation-compose-box-input"]');
}

// ===============================
// TEXT INSERTION (STABLE)
// ===============================
function setText(el, text) {
    if (!el) return;

    el.focus();
    el.innerHTML = "";

    // insert full payload at once
    document.execCommand("insertText", false, text);

    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
}

// ===============================
// MESSAGE PARSER
// ===============================
function getText(msg) {
    const el = msg.querySelector('[data-testid="selectable-text"] span');
    return el ? el.innerText.trim() : "";
}

function getAuthor(msg) {
    const el = msg.querySelector('[data-testid="author"]');
    return el ? el.innerText.trim() : null;
}

// ===============================
// FIND LATEST MENTION
// ===============================
function findLatestMention() {
    const messages = [...document.querySelectorAll('div[data-testid^="conv-msg-"]')];

    const matched = messages
        .map(msg => {
            const text = getText(msg);
            const author = getAuthor(msg);

            return {
                msg,
                text,
                author,
                hasMention: text.includes(targetHandle)
            };
        })
        .filter(m => m.hasMention);

    return matched.length ? matched[matched.length - 1] : null;
}

// ===============================
// WS
// ===============================
function connectWS() {
    ws = new WebSocket("ws://localhost:4567");

    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);

        if (data.type === "response") {
            handleResponse(data.text);
        }

        processing = false;
    };

    ws.onclose = () => setTimeout(connectWS, 2000);
}

connectWS();

// ===============================
// RESPONSE FLOW (NEW MODEL)
// ===============================
async function handleResponse(text) {
    const el = getInputBox();
    if (!el) return;

    const username = lastUserMentioned;
    if (!username) return;

    // 🔥 BUILD FULL MESSAGE FIRST (YOUR IDEA)
    const payload = `${username}\n${text}`;

    // single injection
    setText(el, payload);

    await sleep(50);

    // send
    pressEnter(el);
}

// ===============================
// HELPERS
// ===============================
function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

function pressEnter(el) {
    if (!el) return;

    el.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        bubbles: true
    }));
}

// ===============================
// MAIN LOOP
// ===============================
setInterval(() => {
    if (processing) return;

    const latest = findLatestMention();
    if (!latest) return;

    const text = latest.text;

    if (text === lastMessage) return;

    lastMessage = text;

    if (!text.includes(targetHandle)) return;

    const cleaned = text.replace(new RegExp(targetHandle, "g"), "").trim();
    if (!cleaned) return;

    if (latest.author) {
        lastUserMentioned = latest.author;
    } else {
        return;
    }

    // highlight
    latest.msg.style.border = "2px solid red";
    latest.msg.scrollIntoView({ behavior: "smooth", block: "center" });

    processing = true;

    ws?.send(JSON.stringify({
        type: "request",
        text: cleaned,
        username: lastUserMentioned
    }));

}, 50);
